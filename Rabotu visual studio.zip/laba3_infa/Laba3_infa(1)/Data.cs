﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Lab3_task1
{
    public static class Data
    {
        public static string Copyright;
        public static bool needToCopyright = false;
        public static bool needToGetFiles = false;
        public static string imagePath;
        public static DirectoryInfo directory;
        public static FileInfo file;
        public static List<string> imageDirectories;
    }
}
