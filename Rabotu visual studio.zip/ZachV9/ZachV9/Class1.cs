﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZachV9
{
    class Class1
    {
        public static string strTextChangeN1 { get; set; }
        public static string strTextChangeN2 { get; set; }
        public static string strTextChangeN3 { get; set; }
        public static string strTextChangeN4 { get; set; }
        public static string strTextChangeN5 { get; set; }
        public static string strTextChangeN6 { get; set; }
    }
}
