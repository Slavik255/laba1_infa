﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zachet_zadanie_infa_7
{
    class Class1
    {
        public static string strTextChangeN1 { get; set; }
    }
}
